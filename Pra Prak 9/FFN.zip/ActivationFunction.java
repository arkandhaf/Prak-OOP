public interface ActivationFunction {
    double activate(double x);
}
