public class WorkerThread extends Thread {
    // private final RequestQueue queue;
    // private final int id;

    /*
     * Konstruktor kelas yang menerima RequestQueue dan id worker
     * inisiasi queue dengan parameter q
     * inisiasi id dengan parameter id
     */
    //Type your code here

    /*
     * Implementasikan method run() yang akan terus-menerus mengambil request dari queue
     * menggunakan method dequeue dan memprosesnya.
     * Cetak "Worker-<id> memproses request #<request_id>" setiap kali memproses request.
     * Sleep thread selama 80ms setiap kali memproses request.
     * 
     * Hint: 
     *  - Gunakan isInterrupted() untuk pengecekan interupsi
     *  - Tangani InterruptedException dengan blok try-catch (catch kosong)
     */
    // Type your code here
}
