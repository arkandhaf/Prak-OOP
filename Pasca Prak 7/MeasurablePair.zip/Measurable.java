public interface Measurable<T> extends Comparable<T> {
    double getValue();
}
