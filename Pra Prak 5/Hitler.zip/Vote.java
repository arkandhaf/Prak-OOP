public enum Vote {
  YAY, NAY
}