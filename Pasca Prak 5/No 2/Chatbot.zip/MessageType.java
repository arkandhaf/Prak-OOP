public enum MessageType {
    GREETING,
    QUESTION,
    UNKNOWN;
}
