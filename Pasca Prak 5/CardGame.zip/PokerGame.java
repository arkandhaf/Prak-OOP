public class PokerGame extends CardGame {
    private int blindAmount;

    public PokerGame(int maxPlayers, int blindAmount) {
        super("Poker", maxPlayers);
        this.blindAmount = blindAmount;
    }

    @Override
    public void startGame() {
        System.out.println("Game Poker dimulai! Blind amount: " + blindAmount);
    }

    public enum HandRank {
        HIGH_CARD,
        ONE_PAIR,
        TWO_PAIR,
        THREE_OF_A_KIND,
        STRAIGHT,
        FLUSH,
        FULL_HOUSE,
        FOUR_OF_A_KIND,
        STRAIGHT_FLUSH,
        ROYAL_FLUSH
    }

    public void evaluateHand(Player player) {
        System.out.println("Mengevaluasi hand pemain " + player.getName() + " untuk Poker");
    }

    public HandRank getHandRank(Player player) {
        return HandRank.HIGH_CARD;
    }
}