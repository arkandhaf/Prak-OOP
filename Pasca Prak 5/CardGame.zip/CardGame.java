import java.util.Random;

public class CardGame {
    private String gameName;
    private int maxPlayers;

    public CardGame(String gameName, int maxPlayers) {
        this.gameName = gameName;
        this.maxPlayers = maxPlayers;
    }

    public String getGameName() {
        return gameName;
    }

    public int getMaxPlayers() {
        return maxPlayers;
    }

    // Static nested class Card
    public static class Card {
        private String suit;
        private String rank;
        private int value;

        public Card(String suit, String rank, int value) {
            this.suit = suit;
            this.rank = rank;
            this.value = value;
        }

        public String getSuit() {
            return suit;
        }

        public String getRank() {
            return rank;
        }

        public int getValue() {
            return value;
        }

        public void displayCard() {
            System.out.println(rank + " of " + suit + " (Value: " + value + ")");
        }
    }

    // Inner class Deck
    public class Deck {
        private Card[] cards;
        private int currentSize;

        public Deck(int size) {
            cards = new Card[size];
            currentSize = 0;
        }

        public void addCard(Card card) {
            if (currentSize >= cards.length) {
                System.out.println("Deck penuh!");
                return;
            }
            cards[currentSize] = card;
            currentSize++;
            System.out.println("Kartu ditambahkan ke deck " + gameName);
        }

        public Card drawCard() {
            if (currentSize == 0) {
                System.out.println("Deck kosong!");
                return null;
            }
            Card drawn = cards[currentSize - 1];
            cards[currentSize - 1] = null;
            currentSize--;
            return drawn;
        }

        public void shuffle(long seed) {
            Random rand = new Random(seed);
            for (int i = currentSize - 1; i >= 1; i--) {
                int j = rand.nextInt(i + 1);
                // Swap cards[i] and cards[j]
                Card temp = cards[i];
                cards[i] = cards[j];
                cards[j] = temp;
            }
            System.out.println("Deck " + gameName + " dikocok");
        }

        public void displayDeck() {
            System.out.println("Deck " + gameName + " berisi " + currentSize + " kartu:");
            for (int i = 0; i < currentSize; i++) {
                cards[i].displayCard();
            }
        }
    }

    // Inner class Player
    public class Player {
        private String name;
        private Card[] hand;
        private int score;
        private int cardCount;

        public Player(String name, int handSize) {
            this.name = name;
            this.hand = new Card[handSize];
            this.score = 0;
            this.cardCount = 0;
        }

        public String getName() {
            return name;
        }

        public Card[] getHand() {
            return hand;
        }

        public int getScore() {
            return score;
        }

        public void addCardToHand(Card card) {
            if (cardCount >= hand.length) {
                System.out.println("Tangan " + name + " sudah penuh!");
                return;
            }
            hand[cardCount] = card;
            cardCount++;
            System.out.println(name + " menerima kartu di game " + gameName);
        }

        public Card playCard(int index) {
            if (index < 0 || index >= cardCount) {
                System.out.println("Tidak ada kartu di index tersebut");
                return null;
            }
            Card played = hand[index];
            System.out.print(name + " memainkan kartu:\n");
            played.displayCard();
            
            // Shift cards to the left
            for (int i = index; i < cardCount - 1; i++) {
                hand[i] = hand[i + 1];
            }
            hand[cardCount - 1] = null;
            cardCount--;
            
            return played;
        }

        public void displayHand() {
            System.out.println(name + " memiliki " + cardCount + " kartu:");
            for (int i = 0; i < cardCount; i++) {
                hand[i].displayCard();
            }
        }

        public void calculateScore() {
            score = 0;
            for (int i = 0; i < cardCount; i++) {
                score += hand[i].getValue();
            }
            System.out.println(name + " memiliki total score: " + score);
        }
    }

    public void startGame() {
        System.out.println("Game " + gameName + " dimulai dengan " + maxPlayers + " pemain maksimal!");
    }

    public void startGame(int rounds) {
        System.out.println("Game " + gameName + " dimulai dengan " + rounds + " ronde!");
    }
}