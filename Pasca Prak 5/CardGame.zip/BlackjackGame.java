public class BlackjackGame extends CardGame {
    private int minimumBet;

    public BlackjackGame(int maxPlayers, int minimumBet) {
        super("Blackjack", maxPlayers);
        this.minimumBet = minimumBet;
    }

    @Override
    public void startGame() {
        System.out.println("Game Blackjack dimulai! Minimum bet: " + minimumBet);
    }

    // Inner class Dealer extends Player
    public class Dealer extends Player {
        public Dealer() {
            super("Dealer", 10);
        }

        public void dealCards() {
            System.out.println("Dealer membagikan kartu kepada semua pemain");
        }
    }

    public void hit(Player player) {
        System.out.println("Player " + player.getName() + " mengambil kartu tambahan");
    }

    public void stand(Player player) {
        System.out.println("Player " + player.getName() + " tidak mengambil kartu lagi");
    }

    public void checkBlackjack(Player player) {
        player.calculateScore();
        if (player.getScore() == 21) {
            System.out.println("BLACKJACK! " + player.getName() + " menang!");
        }
    }
}