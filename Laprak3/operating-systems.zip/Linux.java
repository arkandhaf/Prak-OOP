public class Linux extends OperatingSystem {

    public enum Distro { UBUNTU, FEDORA, ARCH, DEBIAN }

    private Distro distroType;

    public Linux(String name, String version, String kernelType, double baseScore, Distro distroType) {
        super(name, version, kernelType, baseScore);
        this.distroType = (distroType == null) ? Distro.UBUNTU : distroType;
    }

    public Distro getDistroType() { return this.distroType; }

    @Override
    public double calculateCompatibility(UsageType usage) {
        double m = 0.0;
        switch (usage) {
            case SERVER: m = 0.20; break;
            case DEVELOPMENT: m = 0.10; break;
            case GAMING: m = -0.15; break;
            default: m = 0.0;
        }
        double base = getBaseScore();
        double raw = base + m * base;
        return clampScore(raw);
    }

    @Override
    protected String getAdditionalInfo() {
        return "Distribution: " + this.distroType.name();
    }
}
