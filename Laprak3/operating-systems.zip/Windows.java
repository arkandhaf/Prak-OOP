public class Windows extends OperatingSystem {

    public enum Edition { HOME, PRO, SERVER }

    private Edition edition;

    public Windows(String name, String version, String kernelType, double baseScore, Edition edition) {
        super(name, version, kernelType, baseScore);
        this.edition = (edition == null) ? Edition.HOME : edition;
    }

    public Edition getEdition() { return this.edition; }

    @Override
    public double calculateCompatibility(UsageType usage) {
        double m = 0.0;
        if (usage == UsageType.GAMING) {
            m += 0.20;
        }
        if (usage == UsageType.SERVER && edition == Edition.SERVER) {
            m += 0.30;
        }
        if (usage == UsageType.SERVER && edition == Edition.HOME) {
            m += -0.05;
        }
        double base = getBaseScore();
        double raw = base + m * base;
        return clampScore(raw);
    }

    @Override
    protected String getAdditionalInfo() {
        return "Edition: " + this.edition.name();
    }
}
