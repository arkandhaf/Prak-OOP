public class WeakPasswordException extends Exception {
    // TODO: Buat konstruktor yang menerima String message dan memanggil super(message).
    public WeakPasswordException(String message) {
        super(message);
    }
}
