public class InvalidNameException extends Exception {
    // TODO: Buat konstruktor yang menerima String message dan memanggil super(message).
    public InvalidNameException(String message) {
        super(message);
    }
}
